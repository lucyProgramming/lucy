package run

import "gitee.com/yuyang-fine/lucy/src/cmd/common"

type PackageCompiled struct {
	packageName string
	meta        *common.PackageMeta
}
