// "past" is short for "print abstract syntax tree"
// "past" will print "ast" in json

package main
