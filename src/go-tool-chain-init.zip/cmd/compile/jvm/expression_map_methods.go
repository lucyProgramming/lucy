package jvm

import (
	"gitee.com/yuyang-fine/lucy/src/cmd/compile/ast"
	"gitee.com/yuyang-fine/lucy/src/cmd/compile/common"
	"gitee.com/yuyang-fine/lucy/src/cmd/compile/jvm/cg"
)

func (this *BuildExpression) buildMethodCallOnMap(
	class *cg.ClassHighLevel,
	code *cg.AttributeCode,
	e *ast.Expression,
	context *Context,
	state *StackMapState) (maxStack uint16) {
	call := e.Data.(*ast.ExpressionMethodCall)
	maxStack = this.build(class, code, call.Expression, context, state)
	stackLength := len(state.Stacks)
	defer func() {
		state.popStack(len(state.Stacks) - stackLength)
	}()
	hashMapVerifyType := state.newObjectVariableType(mapClass)
	state.pushStack(class, hashMapVerifyType)
	switch call.Name {
	case common.MapMethodKeyExist:
		variableType := call.Args[0].Value
		stack := this.build(class, code, call.Args[0], context, state)
		if t := 1 + stack; t > maxStack {
			maxStack = t
		}
		if variableType.IsPointer() == false {
			typeConverter.packPrimitives(class, code, variableType)
		}
		code.Codes[code.CodeLength] = cg.OP_invokevirtual
		class.InsertMethodRefConst(cg.ConstantInfoMethodrefHighLevel{
			Class:      mapClass,
			Method:     "containsKey",
			Descriptor: "(Ljava/lang/Object;)Z",
		}, code.Codes[code.CodeLength+1:code.CodeLength+3])
		code.CodeLength += 3
		if e.IsStatementExpression {
			code.Codes[code.CodeLength] = cg.OP_pop
			code.CodeLength++
		}
	case common.MapMethodRemove:
		currentStack := uint16(1)
		for k, v := range call.Args {
			currentStack = 1
			variableType := v.Value
			if k != len(call.Args)-1 {
				code.Codes[code.CodeLength] = cg.OP_dup
				currentStack++
				if currentStack > maxStack {
					maxStack = currentStack
				}
				state.pushStack(class, hashMapVerifyType)
			}
			stack := this.build(class, code, v, context, state)
			if t := stack + currentStack; t > maxStack {
				maxStack = t
			}
			if variableType.IsPointer() == false {
				typeConverter.packPrimitives(class, code, variableType)
			}
			//call remove
			code.Codes[code.CodeLength] = cg.OP_invokevirtual
			class.InsertMethodRefConst(cg.ConstantInfoMethodrefHighLevel{
				Class:      mapClass,
				Method:     "remove",
				Descriptor: "(Ljava/lang/Object;)Ljava/lang/Object;",
			}, code.Codes[code.CodeLength+1:code.CodeLength+3])
			code.Codes[code.CodeLength+3] = cg.OP_pop
			code.CodeLength += 4
			if k != len(call.Args)-1 {
				state.popStack(1)
			}
		}
	case common.MapMethodRemoveAll:
		code.Codes[code.CodeLength] = cg.OP_invokevirtual
		class.InsertMethodRefConst(cg.ConstantInfoMethodrefHighLevel{
			Class:      mapClass,
			Method:     "clear",
			Descriptor: "()V",
		}, code.Codes[code.CodeLength+1:code.CodeLength+3])
		code.CodeLength += 3
	case common.MapMethodSize:
		code.Codes[code.CodeLength] = cg.OP_invokevirtual
		class.InsertMethodRefConst(cg.ConstantInfoMethodrefHighLevel{
			Class:      mapClass,
			Method:     "size",
			Descriptor: "()I",
		}, code.Codes[code.CodeLength+1:code.CodeLength+3])
		code.CodeLength += 3
		if e.IsStatementExpression {
			code.Codes[code.CodeLength] = cg.OP_pop
			code.CodeLength++
		}
	}
	return
}
