package cg

//type AttributeRuntimeVisibleAnnotation struct {
//	Annotations []*Annotation
//}
//
//func (this *AttributeRuntimeVisibleAnnotation) ToAttributeInfo(class *Class) *AttributeInfo {
//	if this == nil || len(this.Annotations) == 0 {
//		return nil
//	}
//	ret := &AttributeInfo{}
//	return ret
//}
