package cg

const (
	AccMethodPublic       uint16 = 0x0001 //public，方法可以从包外访问
	AccMethodPrivate      uint16 = 0x0002 //private，方法只能本类中访问
	AccMethodProtected    uint16 = 0x0004 //protected，方法在自身和子类可以访问
	AccMethodStatic       uint16 = 0x0008 //static，静态方法
	AccMethodFinal        uint16 = 0x0010 //final，方法不能被重写（覆盖）
	AccMethodSynchronized uint16 = 0x0020 //synchronized，方法由管程同步
	AccMethodBridge       uint16 = 0x0040 //bridge，方法由编译器产生
	AccMethodVarargs      uint16 = 0x0080 //表示方法带有变长参数
	AccMethodNative       uint16 = 0x0100 //native，方法引用非java语言的本地方法
	AccMethodAbstract     uint16 = 0x0400 //abstract，方法没有具体实现
	AccMethodStrict       uint16 = 0x0800 //strictfp，方法使用FP-strict浮点格式
	AccMethodSynthetic    uint16 = 0x1000 //方法在源文件中不出现，由编译器产生
)

type MethodInfo struct {
	AccessFlags            uint16
	NameIndex              uint16
	DescriptorIndex        uint16
	Attributes             []*AttributeInfo
	AttributeGroupedByName AttributeGroupedByName
}

func (m *MethodInfo) IsBridge() bool {
	return m.AccessFlags&AccMethodBridge != 0
}

func (m *MethodInfo) IsSynthetic() bool {
	return m.AccessFlags&AccMethodSynthetic != 0
}
